while true
do
	weather-Cli get Litomysl | grep "Temp" | cut -d ':' -f2 | xargs > ~/.config/sway/teplota
	sleep 1800
done
