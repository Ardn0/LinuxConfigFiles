doas ryzenadj -k 60000 -g 33000 -c 30000 -d 10 -f 80
